> Go 开发者成长路线图，指导Go开发者学习



- [Go 开发者成长路线图 原版](https://github.com/Alikhll/golang-developer-roadmap)

- [Go 开发者成长路线图 中文版](https://github.com/Alikhll/golang-developer-roadmap/blob/master/i18n/ReadMe-zh-CN.md)

  

![2019 Go 开发者成长路线图](../images/golang-developer-roadmap-zh-CN.png) 
