// You can edit this code!
// Click here and start typing.
// https://golang.org/
// https://blog.golang.org/
package main

import "fmt"

func main() {
  fmt.Println("Hello, 世界")
}